<?php
session_start();
include("index.html");
echo $_SESSION['login_user']; ?>
