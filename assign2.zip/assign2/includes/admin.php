<?php
session_start(); //Start the session
if(!isset($_SESSION['login_user'])){ //If session not registered
  echo "my login user is $login_user";
header("location:../index.php"); // Redirect to login.php page
}
// else //Continue to current page
// header( 'Content-Type: text/html; charset=utf-8' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <title>Welcome To Admin Page Demonstration</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/customdiv.css" rel="stylesheet">
</head>
<body>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../js/bootstrap.min.js"></script>
    <?php include("nav_admin.php"); ?>
    <div class="container-fluid" style="margin-top:3%;">
    <h1>Welcome To Admin Page</h1>

    <div class="col-md-10 col-lg-offset-1" >
        <div class="table-responsive" style="width:100%;height:100%;">
        <?php ob_start();
        include 'config.php';
        $sql="SELECT * FROM usr_tab";
        $result=mysqli_query($dbC, $sql);
        $count=mysqli_num_rows($result);
        $pg_no_rw=$count/2;
        $pg_no=ceil($pg_no_rw);
        $x=1;
        echo "<div class=\"col-md-5\">";
        while($x <= $pg_no) {
        echo "<ul class=\"pagination pagination\">
          <li><a href=\"#" . $x . "\" target=\"_blank\">" . $x . "</a></li>
          </ul>";
          $x++;
        }
        echo "</div>";
        echo "<table class=\"table table-hover table-bordered\">
          <thead>
          <tr class=\"row\">
          <th>Name</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Age</th>
          </tr>
          </thead>";
        function pg_query($limit,$offset){
          include 'config.php';
          $sql="SELECT * FROM usr_tab ORDER BY age LIMIT $limit OFFSET $offset";
          $result=mysqli_query($dbC, $sql);
          return $result;
        }
        $x=0;
        $step=2;
        $off=0;
        while ($x < $pg_no) {
          $pg_rs=pg_query($step,$off);
          $off=$off+$step;
          $x++;
          echo "<tbody id=\"$x\">";
          while($row = mysqli_fetch_array($pg_rs)) {
            echo "<tr class=\"row\">";
            echo "<td>";
            echo $row['name'];
            echo "</td>";
            echo "<td>" . $row['phone'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>" . $row['age'] . "</td>";
            echo "</tr>";
          }
          echo "</tbody>";
        }

        // while($row = mysqli_fetch_array($result)) {
        //     echo "<tr class=\"row\">";
        //     echo "<td>";
        //     echo $row['name'];
        //     echo "</td>";
        //     echo "<td>" . $row['phone'] . "</td>";
        //     echo "<td>" . $row['email'] . "</td>";
        //     echo "<td>" . $row['age'] . "</td>";
        //     echo "</tr>";
        //   }

          echo "</table>";
          mysqli_close($dbC);
         ?>
      </div>
    </div>
  </div>
</body>
  <?php include("footer.html"); ?>
</html>
